//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

class xpaynowcheckout_hook_code_memberProfileTab extends _HOOK_CLASS_
{
	/**
	 * Hook placeholder — getBlocks() is not used by the current MainTab implementation
	 * (which uses leftColumnBlocks/mainColumnBlocks instead). Block wiring may need
	 * a separate fix. Kept as a passthrough for forward compatibility.
	 *
	 * @return	array
	 */
	public function getBlocks()
	{
		try
		{
			return parent::getBlocks();
		}
		catch ( \Error | \RuntimeException $e )
		{
			if( \defined( '\IPS\DEBUG_HOOKS' ) AND \IPS\DEBUG_HOOKS )
			{
				\IPS\Log::log( $e, 'hook_exception' );
			}

			if ( method_exists( get_parent_class(), __FUNCTION__ ) )
			{
				return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
			}
			else
			{
				throw $e;
			}
		}
	}
}
